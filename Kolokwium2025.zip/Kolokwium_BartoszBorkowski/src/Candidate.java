// --- KROK 1 ---
// Tworzymy rekord Candidate.
// W Javie (od wersji 14) "record" to specjalny rodzaj klasy służący do
// niemutowalnego (niezmiennego) przechowywania danych.
// Kompilator automatycznie generuje dla niego:
// - prywatne, finalne pole "name"
// - konstruktor przyjmujący to pole (public Candidate(String name))
// - metodę getter (public String name())
// - metody equals(), hashCode() oraz toString()
public record Candidate(String name) {

}