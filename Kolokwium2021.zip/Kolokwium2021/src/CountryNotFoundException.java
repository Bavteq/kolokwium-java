// ==========================================
// KROK 3: Definicja własnego wyjątku
// ==========================================
// Zgodnie z poleceniem, klasa dziedziczy bezpośrednio po klasie Exception (a nie RuntimeException)[cite: 31].
// Dzięki temu tworzymy tzw. wyjątek sprawdzany (checked exception).
// Oznacza to, że kompilator Javy z góry wymusi na programiście obsłużenie go (np. przez blok try-catch)
// lub zadeklarowanie jego rzucania w sygnaturze metody (słówko throws).
// Idealnie spełnia to wymóg zadania: "aby niemożliwa była kompilacja bez przechwycenia go"[cite: 31].
public class CountryNotFoundException extends Exception {

    // Konstruktor wyjątku przyjmujący jako argument łańcuch znaków (w naszym przypadku będzie to nazwa państwa).
    public CountryNotFoundException(String message) {

        // Wywołanie konstruktora klasy bazowej (Exception) i przekazanie do niego wiadomości.
        // Dzięki temu mechanizmowi, późniejsze wywołanie wbudowanej metody getMessage() na obiekcie tego wyjątku
        // zwróci dokładnie ten przekazany tekst (nazwę nieznalezionego państwa).
        // Realizuje to wprost kolejne wymaganie z polecenia[cite: 32].
        super(message);
    }
}