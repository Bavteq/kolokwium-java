import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

// ==========================================
// KROK 1: Definicja abstrakcyjnej klasy nadrzędnej
// ==========================================
// Zgodnie z wytycznymi, klasa Country musi być abstrakcyjna[cite: 16].
public abstract class Country {
    // Klasa posiada prywatne, ostateczne (final) pole name typu String[cite: 17].
    private final String name;

    // KROK 2: Definicja statycznych, prywatnych pól zawierających ścieżki do obu plików CSV[cite: 22].
    private static String confirmedCasesPath;
    private static String deathsPath;

    // Publiczny konstruktor przyjmujący jako argument nazwę państwa i ustawiający go w polu name[cite: 17].
    public Country(String name) {
        this.name = name;
    }

    // Publiczna metoda będąca akcesorem do pola name[cite: 17].
    public String getName() {
        return name;
    }

    // ==========================================
    // KROK 2: Ustawianie plików wejściowych
    // ==========================================
    // Statyczna metoda ustawiająca pliki na wartości argumentów[cite: 23].
    public static void setFiles(String confirmedCases, String deaths) throws FileNotFoundException {
        // Metoda ta musi weryfikować, czy pliki istnieją i czy można je odczytać[cite: 24].
        File f1 = new File(confirmedCases);
        if (!f1.exists() || !f1.canRead()) throw new FileNotFoundException(confirmedCases); // Rzuca wyjątek podając ścieżkę do błędnego pliku[cite: 26, 27].

        File f2 = new File(deaths);
        if (!f2.exists() || !f2.canRead()) throw new FileNotFoundException(deaths);

        confirmedCasesPath = confirmedCases;
        deathsPath = deaths;
    }

    // ==========================================
    // KROK 7: Definicja metod abstrakcyjnych
    // ==========================================
    // Publiczne, czysto wirtualne metody (w Javie oznacza to modyfikator abstract),
    // które przyjmują datę, a zwracają liczbę przypadków i zgonów[cite: 54].
    public abstract int getConfirmedCases(LocalDate date);
    public abstract int getDeaths(LocalDate date);

    // ==========================================
    // KROK 3: Wewnętrzna, pomocnicza klasa i metoda określająca kolumny
    // ==========================================
    // Prywatna, statyczna klasa posiadająca publiczne, ostateczne (final) pola ustawiane w konstruktorze[cite: 33].
    private static class CountryColumns {
        public final int firstColumnIndex;
        public final int columnCount;

        public CountryColumns(int firstColumnIndex, int columnCount) {
            this.firstColumnIndex = firstColumnIndex;
            this.columnCount = columnCount;
        }
    }

    // Prywatna, statyczna metoda otrzymująca napis (pierwszy wiersz pliku CSV) i poszukiwane państwo[cite: 34].
    private static CountryColumns getCountryColumns(String firstRow, String countryName) throws CountryNotFoundException {
        // Kolumny rozdzielone są średnikami[cite: 11].
        String[] cols = firstRow.split(";");
        int firstIndex = -1;
        int count = 0;

        for (int i = 1; i < cols.length; i++) { // Zaczynamy od i=1, gdyż nazwy państw są od 2. kolumny[cite: 5].
            if (cols[i].equals(countryName)) {
                if (firstIndex == -1) firstIndex = i;
                count++;
            } else if (firstIndex != -1) {
                break; // Zakładamy, że prowincje występują w pliku obok siebie. Jeżeli państwo ma prowincje, jego nazwa jest powtarzana[cite: 8].
            }
        }

        // Jeżeli pętla się zakończyła i firstIndex nadal wynosi -1, oznacza to, że nie znaleziono kraju.
        if (firstIndex == -1) {
            throw new CountryNotFoundException(countryName);
        }

        // Zwraca obiekt z informacją o pierwszej kolumnie i liczbie kolumn (co sugeruje też obecność prowincji)[cite: 35, 36].
        return new CountryColumns(firstIndex, count);
    }

    // ==========================================
    // KROK 2 i 5: Główne parsowanie CSV dla pojedynczego kraju
    // ==========================================
    // Publiczna, statyczna metoda zwracająca polimorficzny obiekt typu Country[cite: 28].
    public static Country fromCsv(String countryName) throws CountryNotFoundException {
        // Try-with-resources automatycznie otwiera i na końcu zamyka pliki[cite: 29].
        try (BufferedReader brConf = new BufferedReader(new FileReader(confirmedCasesPath));
             BufferedReader brDeaths = new BufferedReader(new FileReader(deathsPath))) {

            String confFirstRow = brConf.readLine(); // W pierwszym wierszu są państwa[cite: 5].
            brDeaths.readLine(); // Pomijamy pierwszy wiersz w zgonach, struktura jest taka sama[cite: 4].

            // Wywołujemy getCountryColumns wewnątrz fromCsv, co może przekazać dalej CountryNotFoundException[cite: 37].
            CountryColumns cols = getCountryColumns(confFirstRow, countryName);

            String confSecondRow = brConf.readLine(); // W drugim wierszu są prowincje[cite: 6].
            brDeaths.readLine();

            String[] provNames = confSecondRow.split(";");
            Country country;

            // KROK 5: W zależności od rodzaju państwa tworzymy obiekt CountryWithoutProvinces lub CountryWithProvinces[cite: 44].
            // Jeżeli w drugim wierszu znajduje się "nan" lub jest pusty, to kraj nie ma prowincji[cite: 7].
            if (cols.columnCount == 1 && (provNames[cols.firstColumnIndex].equals("nan") || provNames[cols.firstColumnIndex].isEmpty())) {
                country = new CountryWithoutProvinces(countryName);
            } else {
                Country[] provinces = new Country[cols.columnCount];
                for (int i = 0; i < cols.columnCount; i++) {
                    provinces[i] = new CountryWithoutProvinces(provNames[cols.firstColumnIndex + i]);
                }
                // CountryWithProvinces potrzebuje podania całej struktury tablicowej w konstruktorze[cite: 20].
                country = new CountryWithProvinces(countryName, provinces);
            }

            String lineConf;
            String lineDeaths;
            // Daty zapisane są w amerykańskim formacie M/d/yy[cite: 9].
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yy");

            // Dla kolejnych wierszy wczytujemy statystyki wszystkich dat[cite: 48]. W pierwszej kolumnie od 3 wiersza są daty[cite: 9].
            while ((lineConf = brConf.readLine()) != null && (lineDeaths = brDeaths.readLine()) != null) {
                String[] partsConf = lineConf.split(";");
                String[] partsDeaths = lineDeaths.split(";");

                LocalDate date = LocalDate.parse(partsConf[0], formatter);

                // Wywołanie addDailyStatistic dla obiektu CountryWithoutProvinces[cite: 45, 46].
                if (country instanceof CountryWithoutProvinces) {
                    int conf = Integer.parseInt(partsConf[cols.firstColumnIndex]);
                    int death = Integer.parseInt(partsDeaths[cols.firstColumnIndex]); // Mogą tu być ujemne liczby traktowane tak samo[cite: 10].
                    ((CountryWithoutProvinces) country).addDailyStatistic(date, conf, death);
                } else {
                    // Lub dla kolejnych komórek prowincji obiektu CountryWithProvinces[cite: 47].
                    CountryWithProvinces cwp = (CountryWithProvinces) country;
                    Country[] provinces = cwp.getProvinces();
                    for (int i = 0; i < cols.columnCount; i++) {
                        int conf = Integer.parseInt(partsConf[cols.firstColumnIndex + i]);
                        int death = Integer.parseInt(partsDeaths[cols.firstColumnIndex + i]);
                        ((CountryWithoutProvinces) provinces[i]).addDailyStatistic(date, conf, death);
                    }
                }
            }
            return country;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    // ==========================================
    // KROK 6: Wczytywanie z tablicy (przeciążanie metody z Kroku 5)
    // ==========================================
    // Statyczna metoda przyjmująca tablicę nazw i zwracająca tablicę obiektów Country[cite: 49, 50].
    public static Country[] fromCsv(String[] countryNames) {
        List<Country> result = new ArrayList<>();
        for (String name : countryNames) {
            try {
                result.add(fromCsv(name));
            } catch (CountryNotFoundException e) {
                // Jeśli rzucono błąd, wyświetlamy getMessage() na wyjściu i pomijamy to państwo na liście wynikowej[cite: 52].
                System.out.println(e.getMessage());
            }
        }
        return result.toArray(new Country[0]);
    }

    // ==========================================
    // KROK 8: Algorytm sortowania tablicy krajów po zgonach
    // ==========================================
    // Publiczna metoda przyjmująca listę obiektów, datę początkową i końcową[cite: 60].
    public static void sortByDeaths(List<Country> countries, LocalDate start, LocalDate end) {
        // Sortowanie z wykorzystaniem wyrażenia lambda. Malejąca kolejność[cite: 61].
        countries.sort((c1, c2) -> {
            int d1 = countDeathsInRange(c1, start, end);
            int d2 = countDeathsInRange(c2, start, end);
            return Integer.compare(d2, d1);
        });
    }

    // Pomocnicza metoda kalkulująca łączną ilość zgonów między dwoma datami (włącznie)[cite: 61, 62].
    private static int countDeathsInRange(Country c, LocalDate start, LocalDate end) {
        int total = 0;
        LocalDate current = start;
        while (!current.isAfter(end)) {
            total += c.getDeaths(current);
            current = current.plusDays(1);
        }
        return total;
    }

    // ==========================================
    // KROK 9: Zapisywanie statystyk w formie dostosowanej pod Gnuplot
    // ==========================================
    // Metoda saveToDataFile tworząca plik wynikowy w odpowiedniej lokalizacji[cite: 64].
    public void saveToDataFile(String path) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(path))) {
            // W formacie docelowym daty muszą mieć format d.MM.yy[cite: 66].
            DateTimeFormatter formatOut = DateTimeFormatter.ofPattern("d.MM.yy");
            Set<LocalDate> allDates = collectAllDates(this);

            // W pierwszej kolumnie: data, w drugiej: przypadki, w trzeciej: zgony. Kolumny są oddzielone tabulatorami[cite: 65, 66].
            for (LocalDate date : allDates) {
                pw.println(date.format(formatOut) + "\t" + getConfirmedCases(date) + "\t" + getDeaths(date));
            } // W kolejnych wierszach pliku znajdują się wszystkie statystyki dla dat dostępnych z plików CSV[cite: 67].
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Pomocnicza metoda (odpytująca TreeMap lub iterująca po wszystkich prowincjach)
    // mająca na celu wyciągnięcie kompletu dni, za które wprowadzono raporty.
    private Set<LocalDate> collectAllDates(Country c) {
        if (c instanceof CountryWithoutProvinces) {
            return ((CountryWithoutProvinces) c).getStats().keySet();
        } else {
            CountryWithProvinces cwp = (CountryWithProvinces) c;
            Set<LocalDate> dates = new TreeSet<>();
            for (Country p : cwp.getProvinces()) {
                dates.addAll(collectAllDates(p));
            }
            return dates;
        }
    }
}