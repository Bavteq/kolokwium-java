import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class ElectionTurn {

    // --- KROK 4 ---
    // Pole przechowujące listę kandydatów biorących udział w danej turze wyborów.
    private List<Candidate> candidates;

    // --- KROK 7 ---
    // Prywatne pole votes, będące listą obiektów Vote (przechowuje wszystkie głosy z komisji).
    private List<Vote> votes = new ArrayList<>();

    // --- KROK 4 ---
    // Konstruktor, który przyjmuje listę obiektów Candidate i zapisuje ją w polu klasy.
    public ElectionTurn(List<Candidate> candidates) {
        this.candidates = candidates;
    }

    // --- KROK 7 ---
    // Metoda populate() przyjmuje ścieżkę do pliku z wynikami głosowań (np. "1.csv" lub "2.csv").
    public void populate(String path) {
        try {
            // Wczytanie wszystkich linii z pliku
            List<String> lines = Files.readAllLines(Paths.get(path));

            // Pętla zaczyna się od indeksu 1, aby pominąć nagłówek pliku CSV.
            for (int i = 1; i < lines.size(); i++) {
                // Tworzy obiekt Vote na podstawie wiersza z CSV (korzysta z metody z Kroku 6)
                // i dodaje go do listy votes.
                votes.add(Vote.fromCsvLine(lines.get(i), candidates));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // --- KROK 12 ---
    // Metoda zwracająca zwycięzcę tury. Rzuca własny wyjątek NoWinnerException,
    // jeśli nikt nie zdobędzie ponad 50% głosów.
    public Candidate winner() throws NoWinnerException {
        // Oblicza sumę wszystkich oddanych głosów w tej turze (Krok 17 - metoda bezargumentowa)
        Vote summary = summarize();

        // Sprawdza wynik każdego kandydata
        for (Candidate c : candidates) {
            // Korzysta z metody percentage() napisanej w Kroku 9
            if (summary.percentage(c) > 50.0) {
                return c; // Zwraca zwycięzcę, jeśli ma > 50%
            }
        }
        // Jeśli żaden kandydat nie spełnił warunku, rzuca wyjątek
        throw new NoWinnerException();
    }

    // --- KROK 14 ---
    // Metoda zwracająca listę dwóch kandydatów z największą liczbą głosów
    // (potrzebna, by wyłonić uczestników drugiej tury).
    public List<Candidate> runoffCandidates() {
        Vote summary = summarize(); // Pobiera zsumowane wyniki

        // Tworzy kopię listy kandydatów, aby móc ją posortować nie niszcząc oryginału
        List<Candidate> sorted = new ArrayList<>(candidates);

        // Sortuje kandydatów malejąco po liczbie uzyskanych głosów
        sorted.sort((c1, c2) -> Integer.compare(summary.votes(c2), summary.votes(c1)));

        // Zwraca maksymalnie dwóch pierwszych kandydatów (subList od 0 do 2)
        return sorted.subList(0, Math.min(2, sorted.size()));
    }

    // --- KROK 17 (Polimorfizm statyczny) ---
    // Wersja bezargumentowa metody summarize().
    // Podsumowuje wszystkie głosy oddane w danej turze wyborów we wszystkich lokalizacjach.
    public Vote summarize() {
        return Vote.summarize(votes); // Wykorzystuje metodę z Kroku 8
    }

    // --- KROK 17 (Polimorfizm statyczny) ---
    // Wersja metody summarize() z argumentem (lista nazw lokalizacji).
    // Najpierw filtruje głosy (używając metody z Kroku 16), a dopiero potem je sumuje
    // (używając zmodyfikowanej metody z Kroku 17 w klasie Vote).
    public Vote summarize(List<String> location) {
        // filterByLocation -> wybiera tylko te obiekty Vote, które pasują do podanego województwa/powiatu
        // summarize -> tworzy z nich jeden zbiorczy obiekt Vote i ustawia mu nową lokalizację
        return Vote.summarize(Vote.filterByLocation(votes, location), location);
    }
}