// --- KROK 12 ---
// Tworzymy własną klasę wyjątku, która dziedziczy po standardowej klasie Exception.
// Dziedziczenie po Exception (a nie RuntimeException) sprawia, że jest to tzw. "checked exception"
// (wyjątek kontrolowany). Oznacza to, że kompilator Javy wymusza na nas jego obsługę –
// musimy użyć bloku try-catch w miejscu wywołania metody, która go rzuca
// (co idealnie zrobiliśmy w klasie Election w kroku 13 i 15).
public class NoWinnerException extends Exception {

    // Klasa jest pusta, ponieważ potrzebujemy jej tylko jako "sygnału" (flagi),
    // informującego, że żaden kandydat nie zdobył ponad 50% głosów w I turze.
    // Nie potrzebujemy przekazywać w niej żadnych dodatkowych wiadomości tekstowych czy danych.
}