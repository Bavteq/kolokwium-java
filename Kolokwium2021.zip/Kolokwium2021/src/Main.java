import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Używamy bloku try-catch, aby przechwycić ewentualne wyjątki rzucane przez nasze metody
        // Jest to m.in. realizacja wymagań z KROKU 2 (FileNotFoundException) i KROKU 3 (CountryNotFoundException)
        try {

            // ==========================================
            // KROK 2: Ustawienie ścieżek do plików CSV
            // ==========================================
            // Wywołujemy statyczną metodę setFiles z klasy Country.
            // Zgodnie z Krok 2, metoda ta ustawia statyczne, prywatne pola ze ścieżkami do plików
            // z zakażeniami i zgonami. Metoda ta sprawdza również, czy pliki istnieją.
            // Jeśli ich nie ma, rzuci wyjątek FileNotFoundException.
            Country.setFiles("confirmed_cases.csv", "deaths.csv");
            System.out.println("Pliki CSV zostały poprawnie ustawione.\n");

            // ==========================================
            // KROK 2, 4 i 5: Wczytywanie pojedynczego państwa i uzupełnianie statystyk
            // ==========================================
            // Używamy statycznej metody fromCsv (z Kroku 2), która tworzy polimorficzny obiekt typu Country.
            // Zgodnie z Krokiem 5, metoda ta wewnątrz czyta pliki i parsuje z nich dane statystyczne
            // (zakażenia i zgony dzień po dniu za pomocą metody addDailyStatistic z Kroku 4).
            Country poland = Country.fromCsv("Poland"); // Tworzy obiekt CountryWithoutProvinces
            Country australia = Country.fromCsv("Australia"); // Tworzy obiekt CountryWithProvinces

            System.out.println("Pomyślnie wczytano: " + poland.getName() + " oraz " + australia.getName() + ".\n");

            // ==========================================
            // KROK 6: Wczytanie tablicy państw i obsługa błędów wewnątrz
            // ==========================================
            System.out.println("Testowanie metody dla tablicy państw (powinno wyrzucić błąd dla 'Atlantydy'):");
            String[] countryNames = {"Poland", "Australia", "Atlantyda", "Germany"};

            // Używamy przeciążonej metody fromCsv, która przyjmuje tablicę Stringów (Krok 6).
            // Wewnątrz tej metody wywoływana jest pojedyncza wersja fromCsv.
            // Gdy pętla napotka "Atlantydę", pojedyncza metoda fromCsv rzuci CountryNotFoundException (Krok 3).
            // Przeciążona metoda z Kroku 6 musi ten wyjątek "złapać", wypisać błąd na wyjście (System.out)
            // używając getMessage() z wyjątku i pominąć to państwo (nie dodawać go do zwracanej tablicy).
            Country[] countriesArray = Country.fromCsv(countryNames);

            System.out.println("\nKraje załadowane do tablicy:");
            // Wyświetlamy pomyślnie załadowane państwa (powinna tu być Polska, Australia i Niemcy, bez Atlantydy)
            for (Country c : countriesArray) {
                System.out.println("- " + c.getName());
            }

            // ==========================================
            // KROK 8: Sortowanie malejąco według liczby zgonów w przedziale czasowym
            // ==========================================
            System.out.println("\nTestowanie sortowania państw (malejąco według zgonów):");
            // Metoda sortByDeaths przyjmuje Listę, więc zamieniamy tablicę na listę pomocniczą metodą z klasy Arrays
            List<Country> countryList = Arrays.asList(countriesArray);

            // Definiujemy zakres dat do sprawdzenia przy użyciu klasy LocalDate z nowego API daty (wymóg z Kroku 4)
            LocalDate startDate = LocalDate.of(2020, 3, 1);
            LocalDate endDate = LocalDate.of(2020, 5, 31);

            // Wywołanie statycznej metody sortByDeaths z Kroku 8.
            // Metoda ta iteruje po liście państw, dla każdego z nich wylicza sumę zgonów w podanym
            // przedziale (korzystając m.in. z czysto wirtualnych metod z Kroku 7: getDeaths) i sortuje listę.
            Country.sortByDeaths(countryList, startDate, endDate);

            // Wyświetlenie wyniku po sortowaniu
            for (Country c : countryList) {
                System.out.println(c.getName() + " (posortowane)");
            }

            // ==========================================
            // KROK 9: Generowanie pliku wynikowego z danymi dla Gnuplota
            // ==========================================
            System.out.println("\nZapisywanie danych dla państwa " + poland.getName() + " do pliku 'data.txt'...");
            // Wywołujemy publiczną metodę obiektu (instancji), która tworzy plik tekstowy o 3 kolumnach:
            // 1) data w formacie d.MM.yy, 2) potwierdzone przypadki, 3) zgony.
            poland.saveToDataFile("data.txt");
            System.out.println("Zapis zakończony. Plik data.txt jest gotowy do użycia w programie Gnuplot.");

            // ==========================================
            // PRZECHWYTYWANIE WYJĄTKÓW
            // ==========================================
        } catch (FileNotFoundException e) {
            // Ten blok wykonana się, jeśli w Kroku 2 metoda setFiles() uzna, że plików na dysku nie ma.
            System.err.println("Błąd: Nie znaleziono pliku CSV pod ścieżką: " + e.getMessage());
            System.err.println("Upewnij się, że pliki confirmed_cases.csv i deaths.csv są w folderze projektu.");
        } catch (CountryNotFoundException e) {
            // Ten blok chroni nas, jeśli gdzieś wywołamy pojedynczą metodę fromCsv("Nieistniejący_Kraj")
            // Zgodnie z wymaganiami z Kroku 3, łapiemy własny wyjątek, który nie pozwala na kompilację bez jego przechwycenia.
            System.err.println("Błąd krytyczny: Nie znaleziono państwa: " + e.getMessage());
        } catch (Exception e) {
            // Ogólny chwytak na inne, nieprzewidziane błędy (np. błąd formatu w plikach CSV).
            e.printStackTrace();
        }
    }
}