import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Vote {

    // --- KROK 5 ---
    // Prywatna mapa, w której kluczem jest kandydat, a wartością liczba oddanych na niego głosów.
    private final Map<Candidate, Integer> votesForCandidate;

    // Prywatna lista przechowująca lokalizację: [województwo, powiat, gmina].
    private final List<String> location;

    // --- KROK 11 (Optymalizacja) ---
    // Pole służące do "zapamiętania" raz obliczonej sumy wszystkich głosów (cache).
    // Użyto klasy osłonowej Integer, aby móc przechowywać wartość null (zanim suma zostanie obliczona).
    private Integer cachedTotalVotes = null;

    // Konstruktor inicjalizujący obiekt
    public Vote(Map<Candidate, Integer> votesForCandidate, List<String> location) {
        this.votesForCandidate = votesForCandidate;
        this.location = location;
    }

    // --- KROK 6 ---
    // Publiczna, statyczna metoda tworząca obiekt Vote na podstawie jednej linijki tekstu z pliku CSV.
    public static Vote fromCsvLine(String line, List<Candidate> candidates) {
        String[] parts = line.split(","); // Rozdziela dane po przecinku

        // Zapisuje lokalizację w odpowiedniej kolejności (wg pliku: gmina, powiat, woj -> wg wymogów: woj, powiat, gmina).
        List<String> loc = new ArrayList<>();
        loc.add(parts[2]); // Województwo
        loc.add(parts[1]); // Powiat
        loc.add(parts[0]); // Gmina

        // Tworzy mapę głosów i przypisuje kolejne wartości z pliku CSV do kandydatów.
        // Głosy zaczynają się od indeksu 3 w tablicy (bo 0, 1, 2 to lokalizacja).
        Map<Candidate, Integer> votes = new HashMap<>();
        for (int i = 0; i < candidates.size(); i++) {
            votes.put(candidates.get(i), Integer.parseInt(parts[i + 3]));
        }

        // Zwraca w pełni gotowy, wypełniony danymi obiekt
        return new Vote(votes, loc);
    }

    // --- KROK 8 ---
    // Wersja metody summarize podsumowująca listę obiektów Vote i ustawiająca pustą listę jako lokalizację.
    public static Vote summarize(List<Vote> votes) {
        return summarize(votes, new ArrayList<>()); // Przekazuje wywołanie do rozbudowanej metody niżej
    }

    // --- KROK 17 ---
    // Zmodyfikowana wersja metody summarize(), która przyjmuje listę lokalizacji
    // i wpisuje ją do nowo utworzonego, zsumowanego obiektu Vote.
    public static Vote summarize(List<Vote> votes, List<String> location) {
        Map<Candidate, Integer> sum = new HashMap<>();
        if (!votes.isEmpty()) {
            // Najpierw inicjalizuje mapę zerami dla wszystkich kandydatów (kluczy)
            for (Candidate c : votes.get(0).votesForCandidate.keySet()) {
                sum.put(c, 0);
            }
            // Sumuje głosy ze wszystkich przekazanych obiektów Vote
            for (Vote v : votes) {
                for (Map.Entry<Candidate, Integer> entry : v.votesForCandidate.entrySet()) {
                    sum.put(entry.getKey(), sum.get(entry.getKey()) + entry.getValue());
                }
            }
        }
        // Zwraca jeden wielki zagregowany obiekt z nową listą lokalizacji
        return new Vote(sum, location);
    }

    // --- KROK 9 ---
    // Metoda zwracająca całkowitą liczbę głosów oddanych na konkretnego kandydata w tym obiekcie Vote.
    public int votes(Candidate candidate) {
        return votesForCandidate.getOrDefault(candidate, 0);
    }

    // --- KROK 11 ---
    // Prywatna metoda gwarantująca, że suma wszystkich głosów zostanie wyliczona TYLKO RAZ
    // (tzw. "Lazy Initialization" / cashing).
    private int getTotalVotes() {
        if (cachedTotalVotes == null) {
            // Jeśli sumy jeszcze nie policzono (null), liczymy ją teraz:
            int total = 0;
            for (int v : votesForCandidate.values()) {
                total += v;
            }
            cachedTotalVotes = total; // Zapamiętujemy wynik na przyszłość
        }
        // Przy kolejnych wywołaniach funkcji (np. w toString) pętla się już nie odpali,
        // tylko zwróci gotowy wynik
        return cachedTotalVotes;
    }

    // --- KROK 9 i 11 ---
    // Zwraca procentowy udział głosów na kandydata. Wykorzystuje zapamiętaną sumę getTotalVotes().
    public double percentage(Candidate candidate) {
        int total = getTotalVotes();
        if (total == 0) return 0.0; // Zabezpieczenie przed dzieleniem przez zero!
        return (double) votes(candidate) / total * 100.0;
    }

    // --- KROK 10 ---
    // Nadpisana metoda toString(), tak by zwracała ładnie sformatowany tekst
    // w postaci: Imię Nazwisko: XX.XX%
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Candidate c : votesForCandidate.keySet()) {
            sb.append(c.name()).append(": ").append(String.format("%.2f", percentage(c))).append("%\n");
        }
        return sb.toString();
    }

    // --- KROK 16 ---
    // Kluczowa metoda filtrująca wyniki. Przyjmuje listę obiektów Vote oraz listę lokalizacji (loc).
    // Jeśli loc.size() == 1 (tylko woj.), przepuści wszystko z tego woj.
    // Jeśli loc.size() == 2 (woj. i powiat), przepuści z całego powiatu, itd.
    public static List<Vote> filterByLocation(List<Vote> votes, List<String> loc) {
        List<Vote> filtered = new ArrayList<>();
        for (Vote v : votes) {
            boolean match = true;
            // Sprawdza, czy elementy szukanej lokalizacji pokrywają się z faktyczną lokalizacją głosu
            for (int i = 0; i < loc.size() && i < v.location.size(); i++) {
                if (!loc.get(i).equals(v.location.get(i))) {
                    match = false;
                    break;
                }
            }
            // Jeśli się pokrywają, dodaje do nowej przefiltrowanej listy
            if (match) {
                filtered.add(v);
            }
        }
        return filtered;
    }

    // Akcesor (getter) potrzebny na koniec do odczytania zawartości przy tworzeniu mapy.
    public Map<Candidate, Integer> getVotesForCandidate() {
        return votesForCandidate;
    }
}