import java.util.HashMap;
import java.util.Map;

// --- KROK 21 ---
// Tworzymy klasę VoteMap, która dziedziczy po wygenerowanej wcześniej VoivodeshipMap.
// Pozwala nam to zachować logikę rysowania kształtów mapy, ale zmienić to,
// jak dobierane są ich kolory na podstawie wyników wyborów.
public class VoteMap extends VoivodeshipMap {

    // Prywatna struktura danych przechowująca podsumowane wyniki (Vote)
    // dla danego województwa (którego nazwa to klucz String). Zostało to wyliczone w Kroku 19 w Main.
    private Map<String, Vote> results = new HashMap<>();

    // Prywatna mapa pozwalająca przypisać konkretnemu kandydatowi jego barwę (np. "blue", "orange").
    private Map<Candidate, String> candidateColors = new HashMap<>();

    // --- KROK 21 ---
    // Akcesor (setter) służący do przekazania do mapy wyliczonych w klasie Main (Krok 19)
    // wyników głosowania dla poszczególnych województw.
    public void setResults(Map<String, Vote> results) {
        this.results = results;
    }

    // --- KROK 21 ---
    // Metoda pozwalająca w prosty sposób "powiązać kandydatów z wybranymi kolorami" (wymóg z polecenia).
    public void addCandidateColor(Candidate candidate, String color) {
        candidateColors.put(candidate, color);
    }

    // --- KROK 21 ---
    // Nadpisujemy (Override) chronioną metodę getColor() z klasy VoivodeshipMap.
    // Podczas generowania pliku SVG w klasie bazowej, dla każdego województwa
    // wywoływana jest ta metoda, aby sprawdzić, na jaki kolor je narysować.
    @Override
    protected String getColor(String voivodeship) {
        // Krok 1: Pobieramy wyniki głosowania z danego (podanego w argumencie) województwa
        Vote vote = results.get(voivodeship);

        // Zabezpieczenie przed błędem NullPointerException (jeśli nie przekazano wyników)
        if (vote != null) {
            Candidate winner = null;
            int max = -1;

            // Krok 2: Znajdujemy kandydata, który w tym KONKRETNYM województwie uzyskał największą liczbę głosów
            for (Map.Entry<Candidate, Integer> entry : vote.getVotesForCandidate().entrySet()) {
                if (entry.getValue() > max) {
                    max = entry.getValue();
                    winner = entry.getKey();
                }
            }

            // Krok 3: Jeśli udało się wyłonić lokalnego zwycięzcę i ma on przypisany do siebie kolor...
            if (winner != null && candidateColors.containsKey(winner)) {
                // ...zwracamy kolor tego kandydata do narysowania (np. "blue").
                return candidateColors.get(winner);
            }
        }

        // Zabezpieczenie domyślne: jeśli na mapie nie wpisano wyników, kolorujemy ją na szaro.
        return "lightgray";
    }
}