// --- KROK 20 ---
// Tworzymy klasę SelectableMap, która dziedziczy po klasie bazowej VoivodeshipMap.
public class SelectableMap extends VoivodeshipMap {

    // Prywatne pole przechowujące nazwę ostatnio zaznaczonego województwa.
    private String selectedVoivodeship;

    // --- KROK 20 ---
    // Publiczna metoda select(), która przyjmuje nazwę województwa jako argument
    // i zapisuje ją w polu klasy, oznaczając dany region jako "zaznaczony".
    public void select(String voivodeship) {
        this.selectedVoivodeship = voivodeship;
    }

    // --- KROK 20 ---
    // Nadpisujemy (Override) chronioną metodę getColor(), o której mowa w poleceniu.
    // Metoda ta jest wywoływana wewnętrznie podczas generowania pliku SVG w klasie bazowej.
    @Override
    protected String getColor(String voivodeship) {
        // Jeśli sprawdzane właśnie województwo to to, które zaznaczyliśmy...
        if (voivodeship.equals(selectedVoivodeship)) {
            // ...zwracamy wyróżniający się kolor (tutaj czerwony).
            return "red";
        }
        // Wszystkie pozostałe (niezaznaczone) województwa otrzymają kolor domyślny.
        return "lightgray";
    }
}