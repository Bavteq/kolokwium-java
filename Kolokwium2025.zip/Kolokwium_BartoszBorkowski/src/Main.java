import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {

        // --- KROK 3, 13, 15 ---
        // Tworzymy główny obiekt zarządzający wyborami.
        Election election = new Election();

        // Metoda populate() wczytuje kandydatów (Krok 3), ładuje wyniki z 1.csv (Krok 7),
        // sprawdza czy jest zwycięzca I tury (Krok 13). Jeśli nie ma (rzuca NoWinnerException),
        // tworzy drugą turę, ładuje plik 2.csv i ustala ostatecznego zwycięzcę (Krok 15).
        election.populate();

        // --- KROK 13 / 15 ---
        // Wypisujemy ostatecznego zwycięzcę wyborów (wyłonionego w I lub II turze).
        System.out.println("Zwycięzca wyborów: " + election.getWinner().name());

        // --- KROK 4 i 15 ---
        // Pobieramy obiekt drugiej tury. Jeśli ktoś wygrał w I turze, będzie to null.
        ElectionTurn secondTurn = election.getSecondTurn();

        // Wykonujemy wizualizacje i analizę terytorialną tylko, jeśli odbyła się II tura
        if (secondTurn != null) {

            // --- KROK 18 i 19 ---
            // Tworzymy bazową mapę i pobieramy z niej zaimplementowaną w Kroku 19 listę nazw województw.
            VoivodeshipMap baseMap = new VoivodeshipMap();
            List<String> voivodeships = baseMap.getVoivodeships();

            // Przygotowujemy strukturę danych (Mapę) do przechowywania wyników dla każdego województwa (Krok 19).
            Map<String, Vote> resultsByVoivodeship = new HashMap<>();

            // Iterujemy po wszystkich województwach z listy
            for (String v : voivodeships) {
                // --- KROK 17 ---
                // Używamy przeciążonej metody summarize(List<String> location),
                // przekazując nazwę województwa (List.of(v)). Metoda ta filtruje głosy (Krok 16)
                // tylko dla tego województwa i je sumuje.
                resultsByVoivodeship.put(v, secondTurn.summarize(List.of(v)));
            }

            // --- KROK 20 ---
            // Testujemy podklasę SelectableMap. Zaznaczamy "mazowieckie", co powinno
            // na wygenerowanym pliku SVG wyróżnić je innym kolorem.
            SelectableMap selectableMap = new SelectableMap();
            selectableMap.select("mazowieckie");
            selectableMap.saveToSvg("selectable_map.svg");

            // --- KROK 21 ---
            // Testujemy docelową klasę VoteMap dziedziczącą po VoivodeshipMap.
            VoteMap voteMap = new VoteMap();

            // Przekazujemy podsumowane wcześniej wyniki z województw do mapy
            voteMap.setResults(resultsByVoivodeship);

            // --- KROK 14 ---
            // Pobieramy listę dwóch najlepszych kandydatów (uczestników II tury)
            List<Candidate> runoffCandidates = secondTurn.runoffCandidates();

            // --- KROK 21 (ciąg dalszy) ---
            // Dowolnie powiązujemy kandydatów z kolorami (wymagane w poleceniu)
            if (runoffCandidates.size() == 2) {
                voteMap.addCandidateColor(runoffCandidates.get(0), "blue");
                voteMap.addCandidateColor(runoffCandidates.get(1), "orange");
            }

            // Generujemy finalny plik SVG. Każde województwo powinno zostać pokolorowane
            // na kolor tego kandydata, który zdobył w nim najwięcej głosów.
            voteMap.saveToSvg("vote_map.svg");
        }
    }
}