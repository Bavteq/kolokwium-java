import java.time.LocalDate;

// ==========================================
// KROK 1: Definicja klasy i dziedziczenie
// ==========================================
// Zgodnie z wymaganiami, klasa CountryWithProvinces dziedziczy po klasie abstrakcyjnej Country[cite: 16].
public class CountryWithProvinces extends Country {

    // Klasa posiada prywatną tablicę obiektów Country, która reprezentuje prowincje danego państwa[cite: 19].
    // Użycie modyfikatora "final" to dobra praktyka (choć niewymagana wprost w PDF), która gwarantuje,
    // że referencja do tablicy nie zmieni się po zainicjalizowaniu w konstruktorze.
    private final Country[] provinces;

    // Konstruktor klasy przyjmuje nazwę państwa oraz tablicę prowincji[cite: 20].
    public CountryWithProvinces(String name, Country[] provinces) {
        // Wywołanie konstruktora klasy nadrzędnej (Country), aby ustawić nazwę w polu "name"[cite: 17].
        super(name);
        // Ustawienie przekazanej tablicy prowincji w polu klasy[cite: 20].
        this.provinces = provinces;
    }

    // Getter zwracający tablicę prowincji (przydatny w innych częściach programu, np. podczas wczytywania).
    public Country[] getProvinces() {
        return provinces;
    }

    // ==========================================
    // KROK 7: Implementacja metod abstrakcyjnych (polimorfizm i rekurencja)
    // ==========================================

    // Nadpisanie czysto wirtualnej metody getConfirmedCases zdefiniowanej w klasie bazowej Country[cite: 54].
    @Override
    public int getConfirmedCases(LocalDate date) {
        int sum = 0;
        // Pętla iteruje po wszystkich prowincjach (obiektach typu Country) przypisanych do tego państwa.
        for (Country p : provinces) {
            // Ponieważ element 'p' jest typu Country, wywołujemy na nim getConfirmedCases().
            // Jeżeli prowincja jest krajem bez prowincji (CountryWithoutProvinces), zwróci konkretną wartość.
            // Jeżeli w przyszłości prowincja miałaby swoje podprowincje, metoda wywołałaby się ponownie.
            // Jest to realizacja wymogu z Kroku 7, aby wynik zsumować wywołując metodę rekurencyjnie[cite: 58].
            sum += p.getConfirmedCases(date);
        }
        return sum; // Zwracamy zsumowany wynik dla całego państwa.
    }

    // Nadpisanie czysto wirtualnej metody getDeaths zdefiniowanej w klasie bazowej Country[cite: 54].
    @Override
    public int getDeaths(LocalDate date) {
        int sum = 0;
        // Działa dokładnie tak samo jak metoda wyżej - iteruje po tablicy prowincji.
        for (Country p : provinces) {
            // Rekurencyjne wywołanie metody w celu pobrania zgonów dla każdej z prowincji[cite: 58].
            sum += p.getDeaths(date);
        }
        return sum; // Zwracamy całkowitą liczbę zgonów z tego dnia dla całego państwa[cite: 58].
    }
}