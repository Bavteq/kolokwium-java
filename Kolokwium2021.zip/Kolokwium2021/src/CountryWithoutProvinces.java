import java.time.LocalDate;
import java.util.Map;
import java.util.TreeMap;

// ==========================================
// KROK 1: Dziedziczenie klas
// ==========================================
// Zgodnie z wymaganiami, klasa dziedziczy po abstrakcyjnej klasie Country[cite: 16].
public class CountryWithoutProvinces extends Country {

    // ==========================================
    // KROK 4: Projektowanie struktury danych
    // ==========================================
    // Zadanie wymagało samodzielnego zaprojektowania struktury zapisującej zakażenia i zgony dla danego dnia[cite: 39, 40].
    // Użyto tutaj mapy (słownika), gdzie kluczem jest data (zgodnie z wymogiem obiektu LocalDate [cite: 42]),
    // a wartością instancja klasy pomocniczej DailyStats przechowującej dwie liczby całkowite.
    // Użycie TreeMap gwarantuje, że dane będą automatycznie posortowane chronologicznie po dacie.
    private final Map<LocalDate, DailyStats> stats = new TreeMap<>();

    // Konstruktor, który zgodnie z wytycznymi z Kroku 1 wywołuje jedynie konstruktor klasy nadrzędnej (super)[cite: 18].
    public CountryWithoutProvinces(String name) {
        super(name);
    }

    // ==========================================
    // KROK 4: Metoda do dodawania statystyk
    // ==========================================
    // Implementacja publicznej metody addDailyStatistic przyjmującej odpowiednie parametry[cite: 41].
    // Metoda ta tworzy nowy obiekt DailyStats i umieszcza go w słowniku pod kluczem odpowiadającym danej dacie.
    public void addDailyStatistic(LocalDate date, int confirmed, int deaths) {
        stats.put(date, new DailyStats(confirmed, deaths));
    }

    // ==========================================
    // KROK 7: Implementacja metod abstrakcyjnych (pobieranie danych)
    // ==========================================
    // Metody te są wywoływane przez polimorfizm z klasy bazowej Country.
    // Zgodnie z wytycznymi, dla kraju bez prowincji mają one po prostu zwracać wartości zapisane w zdefiniowanej wyżej strukturze[cite: 57].

    @Override
    public int getConfirmedCases(LocalDate date) {
        // Sprawdzamy, czy w mapie istnieje wpis dla podanej daty. Jeśli tak, zwracamy liczbę przypadków.
        // Jeśli nie, zwracamy 0 (zabezpieczenie przed błędem NullPointerException).
        return stats.containsKey(date) ? stats.get(date).confirmed : 0;
    }

    @Override
    public int getDeaths(LocalDate date) {
        // Podobnie jak wyżej, ale pobieramy i zwracamy liczbę zgonów z obiektu DailyStats.
        return stats.containsKey(date) ? stats.get(date).deaths : 0;
    }

    // Metoda pomocnicza (getter), która zapewne przyda się w Kroku 9 podczas iteracji
    // po wszystkich dniach w celu zapisania ich do pliku wyjściowego.
    public Map<LocalDate, DailyStats> getStats() {
        return stats;
    }

    // ==========================================
    // POMOCNICZA STRUKTURA DLA KROKU 4
    // ==========================================
    // Statyczna klasa zagnieżdżona (tzw. rekord lub DTO - Data Transfer Object),
    // która pozwala przechować dwie liczby całkowite jako pojedynczą wartość w naszej mapie.
    public static class DailyStats {
        public final int confirmed;
        public final int deaths;

        public DailyStats(int confirmed, int deaths) {
            this.confirmed = confirmed;
            this.deaths = deaths;
        }
    }
}