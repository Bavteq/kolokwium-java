import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Election {

    // --- KROK 2 ---
    // Prywatne pole candidates - lista obiektów Candidate.
    private List<Candidate> candidates = new ArrayList<>();

    // --- KROK 4 ---
    // Pola przechowujące obiekty pierwszej i drugiej tury wyborów.
    private ElectionTurn firstTurn;
    private ElectionTurn secondTurn;

    // --- KROK 13 ---
    // Prywatne pole przechowujące referencję do zwycięskiego kandydata całych wyborów.
    private Candidate winner;

    // --- KROK 2 ---
    // Metoda zwracająca nową listę, będącą kopią oryginalnej listy candidates.
    // Konstruktor new ArrayList<>(candidates) tworzy tzw. "płytką kopię" (shallow copy),
    // co oznacza, że sama lista jest nowa, ale obiekty w niej zapisane (referencje) pozostają te same.
    public List<Candidate> getCandidates() {
        return new ArrayList<>(candidates);
    }

    // --- KROK 3 ---
    // Metoda przyjmująca ścieżkę do pliku i wczytująca z niego dane kandydatów.
    public void populateCandidates(String path) {
        try {
            // Wczytanie wszystkich linii z pliku
            List<String> lines = Files.readAllLines(Paths.get(path));
            for (String line : lines) {
                // Zabezpieczenie przed pustymi liniami
                if (!line.trim().isEmpty()) {
                    // Dodanie nowego kandydata do listy. (Zgodnie z Krokiem 1, Candidate to rekord).
                    candidates.add(new Candidate(line.trim()));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // --- KROK 3, 7, 13 i 15 ---
    // Główna metoda zasilająca aplikację danymi i wykonująca logikę wyborczą.
    public void populate() {
        // Krok 3: Wywołanie metody wczytującej kandydatów.
        populateCandidates("kandydaci.txt");

        // Krok 4: Utworzenie obiektu pierwszej tury od razu.
        // Obiekt drugiej tury (secondTurn) na razie pozostaje nullem.
        firstTurn = new ElectionTurn(candidates);

        // Krok 7: Wywołanie firstTurn.populate() przekazując plik "1.csv".
        firstTurn.populate("1.csv");

        // Krok 13 i 15: Logika wyłaniania zwycięzcy
        try {
            // Krok 13: Wywołanie metody winner() na pierwszej turze.
            // Jeśli ktoś zdobył >50%, staje się od razu zwycięzcą całych wyborów.
            winner = firstTurn.winner();

        } catch (NoWinnerException e) {
            // Krok 15: Jeśli pierwsza tura rzuci wyjątek NoWinnerException (nikt nie ma >50%),
            // należy zorganizować drugą turę.

            // Uzyskanie listy dwóch kandydatów, którzy zakwalifikowali się do II tury
            List<Candidate> runoff = firstTurn.runoffCandidates();

            // Utworzenie obiektu drugiej tury
            secondTurn = new ElectionTurn(runoff);

            // Wczytanie wyników drugiej tury z pliku "2.csv"
            secondTurn.populate("2.csv");

            try {
                // Ustawienie zwycięzcy drugiej tury jako ostatecznego zwycięzcę wyborów.
                winner = secondTurn.winner();
            } catch (NoWinnerException ex) {
                // W prawdziwym świecie w II turze ktoś musi wygrać (pomijając remisy),
                // ale kompilator wymusza obsługę tego wyjątku.
            }
        }
    }

    // --- KROK 4 ---
    // Akcesor (getter) do obiektu pierwszej tury.
    public ElectionTurn getFirstTurn() {
        return firstTurn;
    }

    // --- KROK 4 ---
    // Akcesor (getter) do obiektu drugiej tury. Będzie nullem, jeśli wybory rozstrzygną się w I turze.
    public ElectionTurn getSecondTurn() {
        return secondTurn;
    }

    // --- KROK 13 ---
    // Akcesor (getter) do ostatecznego zwycięzcy wyborów.
    public Candidate getWinner() {
        return winner;
    }
}